  </div><br><br>
  <div class="col-md-12 text-center">&copy; copyright 2018 - Bishal's Boutique </div>
</body>
</html>
