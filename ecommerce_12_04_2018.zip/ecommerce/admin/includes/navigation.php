<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <a href="/ecommerce/admin/index.php" class="navbar-brand">Boutique Admin</a>
    <ul class="nav navbar-nav">
      <!-- Menu Items -->
      <li> <a href="brands.php">Brands</a> </li>
      <li> <a href="categories.php">Categories</a> </li>

    </ul> <!-- End navbar-nav -->
  </div> <!-- End container-->
</nav> <!-- End navbar -->
