<!-- Left side bar -->
<div class="col-md-2">Left Side Bar	</div><!-- End Left Side Bar -->
