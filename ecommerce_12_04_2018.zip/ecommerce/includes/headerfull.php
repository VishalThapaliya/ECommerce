<!-- Header	-->
<div id="headerWrapper">
  <div id="back-flower"></div> <!-- End back-flower -->
  <div id="logotext"></div> <!-- End logotex
    t -->
  <div id="fore-flower"></div><!-- End fore-flower -->
</div> <!-- End headerWrapper -->

<div class="container-fluid">
